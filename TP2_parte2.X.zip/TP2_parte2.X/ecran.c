#include "ecran.h"
#include "mcc_generated_files/eusart1.h"

void ecranAllume(void)
{
    EUSART1_Write(0xFE);
    EUSART1_Write(0x41);
}

void ecranEteint(void)
{
    EUSART1_Write(0xFE);
    EUSART1_Write(0x42);
}

void cursorPosition(int position)
{
    EUSART1_Write(0xFE);
    EUSART1_Write(0x45);
    EUSART1_Write(position);
    
}

void videEcran(void)
{
    EUSART1_Write(0xFE);
    EUSART1_Write(0x51);
    
}

void ecrireCaracter(char caracter)
{
    EUSART1_Write(caracter);
    
}

void espaceD(void)
{
    EUSART1_Write(0xFE);
    EUSART1_Write(0x56);
}